<!doctype html>
<html>
<head>
</head>
<body><form>
	  		qwert<input type="text" name="name">
			    <a href="#" id="submit" onclick="qwer()">qwert</a>
</form>

<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script>
		function qwer(){
			$('a').click(function(){
				//alert("hello");
				//console.log("hello");
				var name=alert($("#name").val());
				var roll=$("#roll").val();
			});
		}
	</script>
		

</body>
</html>