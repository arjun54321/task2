<?php
include('connection.php');
?>
<!doctype html>
<html>
<head>
	<title>BLOG</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
	<style>
	        body{
		             margin: 0;
		             font-family: Arial, Helvetica, sans-serif;
		        }
		   .body{
			 	     background-size : 100% auto;
			 	     background-color:#fcffff;
			    }
		 .topnav{
		             overflow: hidden;
		             background-color: #a2adad;
		             height:50px;
		        }
    .topnav div {
	                 color: #f2f2f2;
	                 text-align: center;
	                 padding: 14px 16px;
	                 text-decoration: none;
	                 font-size: 30px;
		        }
		    #in {
				    /*border-radius: 10px;*/
				    background-color: #eaecef;
				    padding: 10px;
				    width:100%;
				    font-size:20px;
				}
	    .country{
                    width:200px;   
                }
            .vl {
				    border-left: 3px solid black;
				    height: 500px;
                }
                .scrollable{
	height: 500px;overflow-y: scroll;

}

/* width */
::-webkit-scrollbar {
    width: 5px;
}

/* Track */
::-webkit-scrollbar-track {
    background: transparent; 
}

/* Handle */
::-webkit-scrollbar-thumb {
    background: #020202; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
    background: #555; 
}
	</style>
	</head>
	<body class="body" id="body" background="">
	  <div class="topnav" id="myTopnav">
		    <p style="padding-left: 30px; color:white;font-size:30px">Exam Preparation Online</p>
	  </div><br>
	  <div class="container">
	  	<div class="row">
	  		<form method="GET">
				<div class="col-md-3" >
					<div id="in">
						Oranisation:<br>
						<select name="organization" class="country" >
							<option  name="Google" id="Google" value="Google" >Google</option>
							<option  name="Microsoft" id="Microsoft" value="Microsoft" >Microsoft</option>
							<option  name="Apple" id="Apple" value="Apple" >Apple</option>
							<option  name="Amazon" id="Amazon" value="Amazon" >Amazon</option>
					    </select><br><br>
					    Engineering Stream:<br>
						<select name="country" class="country">
							<option  id="india" value="india" >I.T</option>
							<option  id="china" value="china" >Computer_Science</option>
							<option  id="korea" value="korea" >Mechanical</option>
							<option  id="korea" value="korea" >Civil</option>
					    </select><br><br>
					    Application Mode:<br>
						<select name="application" class="country">
							<option  id="india" value="india" >On Campus</option>
							<option  id="china" value="china" >Off Campus</option>
					    </select>
				    </div><br>
					<div id="in">
						<!-- <a href="#" style="float:right;font-size:15px;color:blue">ClearAll</a> -->
						<input type="checkbox" onClick="selectall(this)"/><b>Select All</b><br/>
						<input type="checkbox" name="foo" value="website_designing">Selection Procedure<br>
						<input type="checkbox" name="foo" value="web_development">Technical Interview<br>
						<input type="checkbox" name="foo" value="web_development">Analytical Questions<br>
						<input type="checkbox" name="foo" value="web_development">HR Questions<br>
						<input type="checkbox" name="foo" value="web_development">Suggestions<br>
				    </div><br>
				    <div style="color:blue;float:right" >
				        <input type="submit" name="submit" value="Apply Filter">
				    </div>
				</div>
			</form>
				<div class="col-md-1">
				     <div class="vl"></div>
			    </div>
			    <div class="col-md-8 scrollable">
			    	<h1>INTERVIEW EXPERIENCES :: <?php echo $_GET['organization']; ?>
			    	</h1><br> 
			<?php
					if(isset($_GET['submit']))
					{
				   $org=$_GET['organization'];
			      $query="SELECT * FROM job";
                  $data=mysqli_query($con,$query);
                  $total=mysqli_num_rows($data);
                  while($result=mysqli_fetch_assoc($data))
		          {
		          	    $org1=$result['organization'];
		          		if($org==$org1)
		          		{
			         echo"<div id='in' style='border-style: solid'>
					      <br><tr><th style='text-align:center;float:left' class='text-primary'>Job Location :&ensp;</th><td style='padding: 20px;'><b>".$result['location']."</b></td></tr><br>
					      <tr><th style='text-align:center;float:left' class='text-primary'>Organisation :&ensp;</th><td style='padding: 20px;'><b>".$result['organization']."</b></td></tr><br>
					      <tr><th style='text-align:center;float:left' class='text-result[primary'>Application Mode :&ensp;</th><td style='padding: 20px;'><b>".$result['application']."</b></td></tr><br>
					      <tr><th style='text-align:center;float:left' class='text-primary'>Selection Procedure :&ensp;</th><td style='padding: 20px;'><b>".$result['selection']."</b></td></tr><br>
					      <tr><th style='text-align:center;float:left' class='text-primary'>Technical Interview :&ensp;</th><td style='padding: 20px;'><b>".$result['interview']."</b></td></tr><br>
					      <tr><th style='text-align:center;float:left' class='text-primary'>Analytical Questions :&ensp;</th><td style='padding: 20px;'><b>".$result['analytical']."</b></td></tr><br>
					      <tr><th style='text-align:center;float:left' class='text-primary'>HR Questions :&ensp;</th><td style='padding: 20px;'><b>".$result['hr']."</b></td></tr><br>
					      <tr><th style='text-align:center;float:left' class='text-primary'>Suggestions :&ensp;</th><td style='padding: 20px;'><b>".$result['suggestions']."</b></td></tr><br>
					      <tr><th style='text-align:center;float:left' class='text-primary'>Shared By :&ensp;</th><td style='padding: 20px;'><b>".$result['shared']."</b><br></td></tr><br></div><br>
		  		          ";
           		  }
           		}
           		}
           		  ?>
			    </div>
			    </div>
	  </div>

	  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script>
        	function selectall(source) {
  checkboxes = document.getElementsByName('foo');
  for(var i=0, n=checkboxes.length;i<n;i++) {
    checkboxes[i].checked = source.checked;
  }
}
        </script>
	</body>
	</html>